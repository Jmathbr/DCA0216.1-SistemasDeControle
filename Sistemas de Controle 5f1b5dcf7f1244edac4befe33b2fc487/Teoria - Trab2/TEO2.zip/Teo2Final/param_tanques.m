%% Parametros da planta
clear all
clc
L0 = [10;10];
a1 = 0.178;
a2 = a1+5e-5;
A1 = 15.518;
A2 = A1 + 3e-5;
Km = 4.6;
g = 981;
sampleTime = 0.2;
%global ny;
%ny = 2;
%global nu;
%nu = 3;
simulationTime = 1500;
%% obs1: o passo de integracao funciona bem quando eh fixo, devido o loop de solucao que o matlab faz para resolver as EDOS.
% as vezes, quando coloca o passo variavel no simulink, ocorre erro.
%% obs2: o metodo para resolver bem o modelo da planta dos sistemas de tanque da quansar, eh satisfatorio com os metodos
% de runge-kutta de ordem maior ou igual a quatro. Nesse exemplo, optou-se
%%% pelo metodo ode5(Dormand-Price)


